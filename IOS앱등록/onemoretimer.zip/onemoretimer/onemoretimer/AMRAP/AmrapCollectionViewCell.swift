//
//  AmrapCollectionViewCell.swift
//  onemoretimer
//
//  Created by 최지석 on 2021/02/25.
//

import UIKit

class AmrapCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var buttonRoundDelete: UIButton!
    @IBOutlet weak var labelRound: UILabel!
    @IBOutlet weak var buttonRest: UIButton!
    @IBOutlet weak var buttonExercise: UIButton!
}
